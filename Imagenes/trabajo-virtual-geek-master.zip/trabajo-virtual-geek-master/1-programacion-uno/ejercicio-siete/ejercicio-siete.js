'use strict'

const listElement = document.querySelector('.list');
const content = '<li>1</li><li>2</li><li>3</li>';

listElement.innerHTML = content;