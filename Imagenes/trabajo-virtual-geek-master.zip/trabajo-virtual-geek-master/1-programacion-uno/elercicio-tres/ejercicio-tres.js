'use strict';

const titleElement = document.querySelector('.title');

titleElement.innerHTML = "¡Hola Mundo!";
