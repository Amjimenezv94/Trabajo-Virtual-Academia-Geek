'use strict'

const passwordElement = document.querySelector('.password');

passwordElement.innerHTML = "***";