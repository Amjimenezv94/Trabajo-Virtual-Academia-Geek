'use strict'

const containerElement = document.querySelector('.container');
const content = '<h1>Lorem ipsum</h1><img src="http://via.placeholder.com/350x150"><p>Lorem Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>';

containerElement.innerHTML = content