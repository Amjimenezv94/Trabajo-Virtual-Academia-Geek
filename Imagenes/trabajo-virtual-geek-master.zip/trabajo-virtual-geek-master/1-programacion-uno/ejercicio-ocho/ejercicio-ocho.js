'use strict'

const section1 = document.querySelector('.button2');

section1.classList.add('hidden');