'use strict';

document.querySelector('h1').innerHTML='Esta página no es compatible con la versión actual de tu navegador. Por favor actualízalo a la versión más reciente.';