// 2 * 5 ; //da 10
// 3 * 2 ; // da 6
// 0.5 * 4; // da 2 

// 10 + 6 + 2 == 18; // €


let kiwi = 2; //kilos
let pearConference = 3; //kilos
let grapes = 0.5; //kilos

totalKiwi = kiwi * 5;
totalPearConference= pearConference * 2;
totalGrapes = grapes * 4;

totalCompra = totalKiwi + totalPearConference + totalGrapes;

console.log("El total de su compra es de: " + totalCompra + "€");

