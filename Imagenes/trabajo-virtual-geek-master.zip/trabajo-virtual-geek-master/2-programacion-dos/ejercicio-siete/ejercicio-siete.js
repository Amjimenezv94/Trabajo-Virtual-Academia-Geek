const friendName = "Laura";
const message = "encantada de conocerte."

 console.log(`hola ${friendName}, ${message}` );