const superWave = document.querySelector('.super-wawe');
superWave.classList.add('super-wave');