23 + 12;

const numeroLaura = 23;
const numeroClara = 12;
suma = numeroClara + numeroLaura;
console.log(suma);