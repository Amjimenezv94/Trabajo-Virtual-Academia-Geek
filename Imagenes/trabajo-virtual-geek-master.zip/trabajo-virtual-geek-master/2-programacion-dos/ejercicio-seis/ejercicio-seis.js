const friendName = "Laura";

 console.log("Hola " + friendName + ", encantada de conocerte.");