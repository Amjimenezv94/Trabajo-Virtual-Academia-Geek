2 + 3 + '5'

'2' + 3 + 5

// Si el string va al inicio el resto de numeros se vuelven string, pero si va al final los primeros números se suman y después el resultado se convierte en string para sumarse con el otro string. 